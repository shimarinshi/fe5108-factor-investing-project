# Part 1 delivery — 21 October 2026

## Merge into the group report

- Use `Part1_submission.docx` as the editable master; `Part1_submission.pdf` is the matching checked preview (5 pages: 2 text + 3 exhibits/sources).
- Merge sections 1A–1E into the main report and exhibits P1A, P1B, P1C(a), P1C(b), P1D and P1E into the exhibits section. Renumber exhibit and source references consistently across the group.
- The key influence diagnostic is included in the P1E note. `Part1_technical_appendix.md` is optional supporting detail; the report has no dangling reference to it.
- Recheck pagination after merging and the assignment's eight-page text limit (exhibits excluded). Add actual member contributions on the group cover page.

## Included files

- Final Word, PDF, and editable Markdown text.
- `inputs/`: unchanged classroom FF/MSCI workbook and assignment handout.
- `tables/`: monthly data, intermediate calculations and numerical results (CSV; return units are decimals unless the field name indicates otherwise).
- `figures/`: only the two figures used in the final report, in PNG and SVG.
- `scripts/`: offline analysis, independent numerical checks, and Word builder.
- `requirements.txt`, optional technical appendix, and `SHA256SUMS.txt`.

Old versions, review drafts, temporary renders, caches and machine-specific environment files are excluded. The package is for the existing private teaching repository and group use.

## Reproduce (in a copy of the extracted folder)

Python 3.10+ is required (Python 3.12 is suitable). Install dependencies:

```sh
python -m pip install -r requirements.txt
python scripts/build_part1.py
python scripts/review_part1.py
python scripts/build_submission.py
```

These commands regenerate numerical outputs, supporting figures, HTML, Word and Markdown; they overwrite generated files in that extracted copy. They do not edit the input files. Export the rebuilt Word to PDF with Microsoft Word or LibreOffice and check every page; no Codex-specific renderer is required. The delivered PDF is already verified and should be retained until a replacement is checked.

The independent checker verifies 830 numerical results against the raw workbook. The final small revision changed prose, exhibit labels and chart presentation; all numerical tables remained unchanged. The five delivery pages were visually inspected.

## Repository status

This ZIP is a self-contained Part 1 handoff, not an integration into the repository's `run_all.py`. Raw inputs inside the archive are included for the requested standalone delivery; reuse the repository's canonical shared data rather than copying these again when integrating code. Parts 2–3 and group-wide completion are outside this package.
