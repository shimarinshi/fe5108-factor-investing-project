# Part 1 Technical Appendix

This appendix accompanies the concise report module. It retains calculation detail and diagnostics that are not necessary to read the main argument.

## Inputs and transformations

The sole numerical source is `inputs/classroom_part1.xlsx`. FF values are divided by 100; MSCI numeric text is converted to positive USD Gross total-return index levels and month-to-month simple returns. December 1994 levels are retained to form January 1995 returns. No published current-series values replace the classroom vintage. Sample standard deviations use n−1. `audit_manifest.json` records the workbook hash; `review_results.json` records independent raw-input verification.

## Factor definitions and means

SMB averages the returns of the three small size–B/M portfolios and subtracts the three-big average. HML averages small and big high-B/M returns and subtracts the analogous low-B/M average. Market excess return is used directly, not reduced by RF again. Mean tests are ordinary arithmetic-mean tests, as the assignment permits; a price-return CAGR would answer a different question.

Supplementary independent-window normal tests compare later minus earlier means. The size and value p values, 0.484 and 0.185, do not establish a publication-induced decline. Differences in within-period significance are not themselves tests of mean differences.

## Diversification calculations

Each index weight is 0.25. The annual covariance matrix is twelve times the sample monthly covariance matrix. Multiplying it by the weights on both sides gives portfolio variance 0.02074003 and volatility 14.401401%. The diagonal variance contribution is 0.00587409; the off-diagonal covariance contribution is 0.01486595. Both are variance units, not volatility contributions.

The counterfactual perfectly correlated risk level is the weighted mean of individual volatilities, 15.208173%. Actual volatility is lower by 0.806773 percentage points, or 5.304861% relative. This does not represent the historical volatility of a separate tradable strategy. Factor total-return correlations are distinct from the active-return correlations required by 1D.

Files: `1C_factor_index_return_correlations.csv`, `1C_factor_index_covariance_annual.csv`, `1C_diversification_evidence.csv` and `1C_risk_contributions.csv` in `tables/`. The last file reports weights times marginal variance contributions and their shares; those shares sum to one.

## Return and Sharpe conventions

The primary annualized average is twelve times the arithmetic monthly mean; annual volatility is √12 times the sample monthly standard deviation. CAGR is shown separately. Sharpe follows the question's denominator of strategy-return volatility. RF's literal ratio is zero because it is compared with itself; this should not be interpreted as a meaningful risk-adjusted ranking. Using its own excess-return volatility would instead give 0/0. The mix is monthly rebalanced; there are no implementation costs, taxes or ETF fees. The sample does not separately identify index-launch and backfilled periods.

## Momentum index interpretation

The report follows the assignment-linked December 2013 MSCI document. Positive Z scores govern priority selection; incumbent buffers must also be considered, so positivity should not be asserted for every retained security at every date. The score is 1+Z for positive Z and the reciprocal of 1−Z otherwise. Z-score truncation governs scores and weights, whereas selection uses uncapped Z. The example raw weights precede normalization and issuer caps; they are not final holdings. The official conditional-review rule uses daily market data and does not coincide with the monthly twelve-month-volatility exercise in 1E.

## Volatility timing and inference

The main same-month model is descriptive: its rolling window includes current market returns. The prior-month supplement uses only completed earlier months. Both use December 1995–July 2023, 332 observations. To align the first lagged observation, the classroom FF series supplies December 1994–November 1995. Annualizing the predictor rescales the slope but does not change its significance. A ten-percentage-point rise in annualized volatility changes monthly momentum by about -2.67 percentage points in the same-month linear fit.

HAC uses a Bartlett kernel with twelve monthly lags and T/(T−2) correction. The p values are asymptotic normal approximations. HAC(3) sensitivity estimates and 95% intervals are in `1E_regressions_HAC.csv`. Full-sample volatility terciles are descriptive, with no causal or implementable real-time interpretation. No bin mean is presented as having passed a separate significance test.

## Post hoc influence diagnostic

Temporarily omitting the two worst momentum months, January 2001 and April 2009, gives:

| Predictor | n | Slope | HAC 12 SE | Approximate p |
| --- | --- | --- | --- | --- |
| vol_t | 330 | -0.1983 | 0.0943 | 0.0355 |
| vol_t_minus_1 | 330 | -0.1609 | 0.0904 | 0.0751 |

This is a diagnostic selected after observing the outcome, not a new cleaned sample or a confirmatory test. The original monthly calendar is retained for HAC lag spacing. Full-sample calculations retain both months. The lagged relation stays negative, but the diagnostic p value rises above 0.05; the evidence does not justify strong claims of stable predictability.

## Reproduce

1. Run `python3 scripts/build_part1.py` with numpy, pandas, openpyxl and matplotlib to regenerate numerical results and the detailed HTML.
2. Run `python3 scripts/review_part1.py` to independently check the calculations from raw Excel.
3. Run `python3 scripts/build_submission.py` with python-docx, pandas and its dependencies to rebuild the Word module and this appendix.
4. Open the rebuilt Word file in Microsoft Word or LibreOffice and export it to PDF. Inspect every page before replacing the delivered PDF; pagination may vary with Office and font versions. The PDF in this delivery has already been checked.

`Part1_submission.md` contains the report text for merging. Group-wide exhibit numbering and reference numbering may be changed during assembly. The supplied Part 1 module contains no invented cover-page contributions; those belong to the full group report.
