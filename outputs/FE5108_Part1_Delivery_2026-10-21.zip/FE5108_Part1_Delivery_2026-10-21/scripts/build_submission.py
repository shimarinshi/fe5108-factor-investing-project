"""Build the mergeable Part 1 document using bundled Python dependencies.
Run after build_part1.py. Render with the packaged render_docx.py.
"""
from pathlib import Path
import json, math
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'tables';F=ROOT/'figures'
a=pd.read_csv(T/'1A_factor_mean_tests.csv')
perf=pd.read_csv(T/'1C_performance.csv',index_col=0)
sc=pd.read_csv(T/'1C_factor_index_return_correlations.csv',index_col=0)
dm=pd.read_csv(T/'1C_diversification_evidence.csv').set_index('metric').value
ac=pd.read_csv(T/'1D_correlations_4x4.csv',index_col=0)
er=pd.read_csv(T/'1E_regressions_HAC.csv')
g=pd.read_csv(T/'1E_volatility_terciles.csv')
inf=pd.read_csv(T/'1E_extreme_month_sensitivity.csv')
pre=a[a.period=='1927-1992'].set_index('factor');post=a[a.period=='1993-2023Jul'].set_index('factor')
main=er[(er.specification=='vol_t')&(er.lags==12)].iloc[0]
lag=er[(er.specification=='vol_t_minus_1')&(er.lags==12)].iloc[0]
styles=['Value','MinVol','EqualWeight','Momentum']
meanvol=dm['mean_constituent_vol_and_perfect_positive_correlation_reference'];mixvol=dm['multifactor_vol_annual']
FF='https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html'
MOM='https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_10_port_form_pr_12_2.html'
BETA='https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_port_form_BETA.html'
MSCI='https://www.msci.com/eqb/methodology/meth_docs/MSCI_Momentum_Indices_Methodology.pdf'

# Main prose is deliberately kept separate from numerical exhibits and technical notes.
content={
'intro': 'We examine whether academic factor premia persist, how investable factor indexes differ, and whether diversification and market volatility affect their outcomes. All numerical results use the classroom workbook [1]. MSCI comparisons cover January 1995 to July 2023, using 343 monthly Gross USD returns.',
'1A': [
f'Exhibit P1A reports ordinary mean t statistics using arithmetic monthly returns, without autocorrelation adjustment as permitted. Before 1993, t values for Mkt−RF, SMB and HML are {pre.loc["Mkt-RF","t_mean"]:.2f}, {pre.loc["SMB","t_mean"]:.2f} and {pre.loc["HML","t_mean"]:.2f}; afterwards they are {post.loc["Mkt-RF","t_mean"]:.2f}, {post.loc["SMB","t_mean"]:.2f} and {post.loc["HML","t_mean"]:.2f}. At the 5% two-sided level, all three earlier means are significant, but only the later market mean is. Size and value therefore warrant less investment conviction. Their lower later means do not establish disappearance: supplementary independent-window mean-difference tests have approximate p values of 0.484 and 0.185. Neither rejects equal means at 5%, and publication is not identified as the cause.',
'For subsequent analysis, we subtract the lowest momentum decile from the highest, and the highest beta decile from the lowest, using value-weighted monthly portfolios [3,4]. These are return spreads. They are not compounded as standalone fully invested portfolios, and the momentum spread is not replaced by the library’s different 2-by-3 Mom factor.'
],
'1B': [
'The assigned December 2013 methodology [5] starts from MSCI USA large- and mid-cap constituents. Six- and twelve-month local price gains, excluding the latest month and less local risk-free rates, are scaled by three-year weekly-return volatility. Each risk-adjusted signal is standardized across stocks by subtracting its cross-sectional mean and dividing by its cross-sectional standard deviation. The two Z scores are equally combined and standardized again; the final Z is clipped at ±3 and mapped to a positive score: 1+Z for Z>0, and 1/(1−Z) otherwise. Selection ranks unclipped Z scores, with parent weight breaking ties. For a reviewed target of N stocks, the top 0.5N ranks enter first; incumbents ranked up to 1.5N are then retained in rank order until N places are filled, with any vacancies filled by rank. Final weights normalize parent weight times momentum score, subject to a 5% USA issuer cap.',
'This combines size and signal strength. For example, parent weights of 2% and 1%, with scores of 1.5 and 2, give raw weights of 0.03 and 0.02 before normalization and caps. The stronger signal need not receive the greater allocation. In our interpretation, capitalization supports trading capacity and reduces the risk of oversized positions in small stocks with strong signals relative to pure signal weighting. It can dilute momentum exposure and retain large-company concentration.',
'Scheduled reviews occur in May and November. Extra reviews monitor exceptional relative increases in the parent’s three-month daily volatility against a historical 95th-percentile threshold, using World as the USA reference. They use only six-month momentum to mitigate volatility-spike drawdowns [5]. This monthly-data exercise does not replicate that daily trigger or assume the 2013 rules held throughout the full return history.'
],
'1C': [
f'The four factor indexes are reset to 25% each month. Exhibit P1B uses arithmetic annualized means and the assignment Sharpe definition: annualized mean less RF mean, divided by strategy-return volatility. Momentum has the highest mean ({perf.loc["Momentum","mean_annual_arithmetic"]:.2%}); Value the lowest ({perf.loc["Value","mean_annual_arithmetic"]:.2%}). Momentum and MinVol have nearly tied Sharpes ({perf.loc["Momentum","sharpe_assignment"]:.3f} and {perf.loc["MinVol","sharpe_assignment"]:.3f}), without a formal test of their difference. Value also has the lowest factor-index Sharpe ({perf.loc["Value","sharpe_assignment"]:.3f}). The mix has mean {perf.loc["MultiFactor","mean_annual_arithmetic"]:.2%}, volatility {mixvol:.2%} and Sharpe {perf.loc["MultiFactor","sharpe_assignment"]:.3f}, versus USA’s {perf.loc["USA","mean_annual_arithmetic"]:.2%}, {perf.loc["USA","vol_annual"]:.2%} and {perf.loc["USA","sharpe_assignment"]:.3f}. Its Sharpe exceeds USA, Value and EqualWeight, but remains below Momentum and MinVol.',
f'Exhibits P1C(a)–(b) quantify diversification. Pairwise factor-index return correlations are {dm["minimum_pairwise_total_return_correlation"]:.3f}–{dm["maximum_pairwise_total_return_correlation"]:.3f}. With the same individual volatilities but perfect positive correlation, the mix’s volatility would equal their weighted average, {meanvol:.2%}. The observed {mixvol:.2%} is lower by {(meanvol-mixvol)*100:.2f} percentage points, or {dm["vol_reduction_relative"]:.1%} relative to that analytical reference. Imperfect correlation therefore reduces risk, despite substantial common equity exposure. This does not identify a tradable benchmark or imply dominance over MinVol alone, whose volatility is {perf.loc["MinVol","vol_annual"]:.2%}. Returns are gross of implementation costs; CAGR is supplementary, not substituted for the mean.'
],
'1D': [
f'Exhibit P1D correlates each MSCI factor return less USA with the four academic spreads. Corresponding correlations are {ac.loc["Value","HML"]:.3f} for Value–HML, {ac.loc["EqualWeight","SMB"]:.3f} for EqualWeight–SMB, {ac.loc["Momentum","MOM_decile"]:.3f} for momentum and {ac.loc["MinVol","LOWBETA_decile"]:.3f} for MinVol–low beta. Factor identities remain recognizable, but construction matters. EqualWeight is a weak substitute for SMB and correlates more with HML ({ac.loc["EqualWeight","HML"]:.3f}). Academic spreads use broader stock sorts, while MSCI active returns subtract a large/mid-cap index. HML balances value spreads across size groups; equal weighting is not a pure size sort, and minimum variance is not a beta sort. These comparisons describe co-movement, not causal exposure estimates [2–4].'
],
'1E': [
f'From December 1995 to July 2023, trailing twelve-month Mkt−RF volatility is negatively associated with same-month decile momentum. OLS gives a slope of {main.slope:.3f}, HAC(12) p={main.slope_p_hac_normal:.3f} and R²={main.r_squared:.1%} (Exhibit P1E). A ten-percentage-point increase in annualized market volatility corresponds to {abs(main.slope*.1*100):.2f} percentage points lower monthly momentum return. The relation is not monotonic: low-, middle- and high-volatility terciles have annualized mean spreads of 12.47%, 22.34% and −12.33%.',
f'The prior-month volatility specification avoids including contemporaneous market returns, but explains only {lag.r_squared:.1%} of momentum variation (HAC(12) p={lag.slope_p_hac_normal:.3f}). Its significance is sensitive to extreme months in the supplementary influence diagnostic. We conclude that this sample contains a weak negative linear association, with particularly poor average momentum in high-volatility states. It does not establish stable forecasting ability, causality or the performance of MSCI’s conditional review rule. Full-sample results remain primary; the influence diagnostic is summarized in the note to Exhibit P1E.'
]
}

doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.72)
sec.left_margin=sec.right_margin=Inches(.78)
sec.header_distance=sec.footer_distance=Inches(.3)
styles_doc=doc.styles
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
    style=styles_doc[name];style.font.name='Times New Roman';style.font.color.rgb=RGBColor(0,0,0)
    style.element.get_or_add_rPr().rFonts.set(qn('w:ascii'),'Times New Roman')
    style.element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'),'Times New Roman')
    fonts=style.element.get_or_add_rPr().rFonts
    for attr in list(fonts.attrib):
        if 'theme' in attr.lower():del fonts.attrib[attr]
# The installed default template has decorative Title borders; remove them.
for node in list(doc.styles.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
styles_doc['Normal'].font.size=Pt(11)
styles_doc['Normal'].paragraph_format.line_spacing=1.06
styles_doc['Normal'].paragraph_format.space_after=Pt(5)
styles_doc['Title'].font.size=Pt(17);styles_doc['Title'].paragraph_format.space_after=Pt(7)
styles_doc['Heading 1'].font.size=Pt(12);styles_doc['Heading 1'].font.bold=True
styles_doc['Heading 1'].paragraph_format.space_before=Pt(9);styles_doc['Heading 1'].paragraph_format.space_after=Pt(4)
styles_doc['Heading 2'].font.size=Pt(11);styles_doc['Heading 2'].font.bold=True
styles_doc['Heading 2'].paragraph_format.space_before=Pt(8);styles_doc['Heading 2'].paragraph_format.space_after=Pt(4)
styles_doc['Caption'].font.size=Pt(9.5);styles_doc['Caption'].paragraph_format.space_after=Pt(7)
styles_doc['Caption'].font.bold=False;styles_doc['Caption'].font.italic=False
doc.core_properties.title='Part 1 Factor Investing'
doc.core_properties.subject='FE5108 factor investing analysis and exhibits'
doc.core_properties.author=''
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run();r.font.size=Pt(9)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');r._r.addnext(fld)

md=[]
def p(text,style=None):
    para=doc.add_paragraph(text,style=style)
    para.paragraph_format.widow_control=True
    md.append(text+'\n')
    return para
def heading(text,level=1):
    doc.add_heading(text,level=level);md.append('#'*(level+1)+' '+text+'\n')
def table(headers,rows,widths):
    tab=doc.add_table(rows=1,cols=len(headers));tab.alignment=WD_TABLE_ALIGNMENT.CENTER;tab.autofit=False
    tabPr=tab._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for k in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+k);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    tabPr.append(borders)
    for col,width in zip(tab.columns,widths):col.width=Inches(width)
    for cell,text,width in zip(tab.rows[0].cells,headers,widths):cell.text=str(text);cell.width=Inches(width)
    repeat=OxmlElement('w:tblHeader');repeat.set(qn('w:val'),'true');tab.rows[0]._tr.get_or_add_trPr().append(repeat)
    for row in rows:
        cells=tab.add_row().cells
        for cell,text,width in zip(cells,row,widths):cell.text=str(text);cell.width=Inches(width)
    for i,row in enumerate(tab.rows):
        cant=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cant)
        for j,cell in enumerate(row.cells):
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcPr=cell._tc.get_or_add_tcPr();marg=OxmlElement('w:tcMar')
            for key,v in [('top',65),('bottom',65),('left',75),('right',75)]:
                node=OxmlElement('w:'+key);node.set(qn('w:w'),str(v));node.set(qn('w:type'),'dxa');marg.append(node)
            tcPr.append(marg)
            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'233F56' if i==0 else ('F2F5F7' if i%2==0 else 'FFFFFF'));tcPr.append(shade)
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(0);para.paragraph_format.line_spacing=1.0
                para.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size=Pt(10);run.font.bold=(i==0)
                    run.font.color.rgb=RGBColor(255,255,255) if i==0 else RGBColor(0,0,0)
    md.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n')
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return tab
def caption(text):p(text,'Caption')
def picture(filename,width=6.75):
    para=doc.add_paragraph();para.paragraph_format.space_after=Pt(3)
    para.add_run().add_picture(str(F/filename),width=Inches(width))
    # Alt text helps identify what each exhibit shows outside the PDF render.
    for dp in para._p.xpath('.//wp:docPr'):dp.set('descr',filename.replace('_',' '))
    md.append('!['+filename+'](figures/'+filename+')\n')
def linkpara(prefix,label,url):
    para=doc.add_paragraph(prefix);para.paragraph_format.space_after=Pt(2)
    for run in para.runs:run.font.size=Pt(9.5)
    hyperlink=OxmlElement('w:hyperlink');hyperlink.set(qn('r:id'),para.part.relate_to(url,RT.HYPERLINK,is_external=True))
    run=OxmlElement('w:r');rPr=OxmlElement('w:rPr');sz=OxmlElement('w:sz');sz.set(qn('w:val'),'19');rPr.append(sz);run.append(rPr)
    txt=OxmlElement('w:t');txt.text=label;run.append(txt);hyperlink.append(run);para._p.append(hyperlink)
    md.append(prefix+f'[{label}]({url})\n')

doc.add_paragraph('Part 1 Factor Investing',style='Title');md.append('# Part 1 Factor Investing\n')
p(content['intro'])
heading('1A Factor premia and statistical evidence')
for text in content['1A']:p(text)
heading('1B MSCI momentum construction')
for text in content['1B']:p(text)
doc.add_page_break();md.append('\n<!-- Body page 2 -->\n')
for key,title in [('1C','Diversification and investment performance'),('1D','Sensitivity to factor construction'),('1E','Momentum and market volatility')]:
    heading(key+' '+title)
    for text in content[key]:p(text)

# Exhibits page 1: exact required statistics and investment comparisons.
doc.add_page_break();heading('Part 1 Exhibits')
heading('Exhibit P1A Mean factor return tests',2)
rows=[]
for row in a.itertuples():
    rows.append(['1927–1992' if row.period=='1927-1992' else '1993–Jul 2023',row.factor,str(row.n),f'{row.mean_monthly:.3%}',f'{row.mean_annual_arithmetic:.2%}',f'{row.t_mean:.3f}'])
table(['Period','Factor','Months','Monthly mean','Annual mean','Mean t'],rows,[1.35,.9,.65,1.1,1.1,.8])
caption('Source: classroom FF3 monthly US research factors [1,2]. Annual mean is 12 times the monthly arithmetic mean; t uses the sample standard deviation divided by the square root of the observation count. No HAC adjustment is applied.')
heading('Exhibit P1B Index performance',2)
rows=[]
for name,row in perf.iterrows():
    rows.append([name,f'{row.mean_annual_arithmetic:.2%}',f'{row.vol_annual:.2%}',f'{row.sharpe_assignment:.3f}',f'{row.cagr:.2%}'])
table(['Index or asset','Annual mean','Annual volatility','Sharpe','CAGR'],rows,[1.55,1.15,1.4,1.0,1.3])
caption('Source: classroom MSCI USA large/mid-cap Gross USD indexes and FF RF [1]. January 1995–July 2023; 343 monthly observations. MultiFactor resets the four factor-index weights to 25% monthly. Volatility uses the sample standard deviation times √12; Sharpe uses strategy-return volatility as required. RF gives zero under the literal formula, but is not a meaningful risk-adjusted ranking: its variation reflects changing bill rates. No costs or fees are deducted.')
heading('Exhibit P1C(a) Risk diversification benchmarks',2)
table(['Risk reference','Annual volatility'],[
['Weighted mean of four individual volatilities',f'{meanvol:.2%}'],
['Four-index mix using observed covariance',f'{mixvol:.2%}'],
['MSCI USA market index',f'{perf.loc["USA","vol_annual"]:.2%}'],
['MSCI USA MinVol alone',f'{perf.loc["MinVol","vol_annual"]:.2%}'],
],[4.8,1.6])
caption(f'Same source, universe and period as Exhibit P1B. Holding each constituent volatility fixed, perfect positive correlation gives the first-row risk level. The mix reduces volatility by {(meanvol-mixvol)*100:.2f} percentage points ({dm["vol_reduction_relative"]:.1%} relative). This analytical reference isolates imperfect-correlation benefits; it is not an investable alternative portfolio.')

# Exhibits page 2: diversification evidence and academic vs practitioner mapping.
doc.add_page_break();heading('Exhibit P1C(b) Correlation and portfolio risk')
table(['Index','Value','MinVol','EqualWeight','Momentum'],[
    [name,*[f'{sc.loc[name,c]:.3f}' for c in styles]] for name in styles
],[1.45,1.0,1.0,1.4,1.2])
caption('Source: classroom MSCI USA factor-index Gross USD monthly returns, January 1995–July 2023, n=343. This table uses total returns; Exhibit P1D instead uses returns relative to USA. Portfolio variance is calculated from the same sample covariance matrix with four 25% weights.')
picture('1C_diversification_risk.png')
caption('Source and period as above. The grey bar holds each individual volatility fixed and sets all pairwise correlations to +1. Common equity exposure limits the size of the diversification benefit.')
heading('Exhibit P1D Academic and MSCI factor correlations',2)
table(['MSCI less USA','HML','SMB','High–low mom','Low–high beta'],[
    [name,*[f'{ac.loc[name,c]:.3f}' for c in ['HML','SMB','MOM_decile','LOWBETA_decile']]] for name in ['Value','MinVol','EqualWeight','Momentum']
],[1.5,.8,.8,1.5,1.5])
caption('Source: classroom MSCI USA Gross USD indexes and FF monthly US research portfolios [1–4]. January 1995–July 2023, n=343 in every cell. Rows subtract USA from each factor-index return. Columns are HML, SMB, highest minus lowest momentum decile, and lowest minus highest beta decile; decile legs use value-weighted returns.')

# Exhibits page 3: primary inference, nonlinear state description and references.
doc.add_page_break();heading('Exhibit P1E Momentum and market volatility')
table(['Volatility window','Months','Slope','HAC SE','Approx p','R squared'],[
    ['Through current month','332',f'{main.slope:.3f}',f'{main.slope_se_hac:.3f}',f'{main.slope_p_hac_normal:.3f}',f'{main.r_squared:.1%}'],
    ['Through prior month','332',f'{lag.slope:.3f}',f'{lag.slope_se_hac:.3f}',f'{lag.slope_p_hac_normal:.3f}',f'{lag.r_squared:.1%}'],
],[2.0,.65,.8,.85,.8,.95])
caption('Source: classroom US FF Mkt−RF and value-weighted momentum deciles [1–3]. December 1995–July 2023. Predictor: trailing twelve-month sample standard deviation times √12; outcome: monthly high-minus-low momentum spread. Bartlett HAC(12), T/(T−2) correction, asymptotic normal two-sided p values. Returns and volatility enter as decimals. The first prior-month window uses December 1994–November 1995; the primary current-month window uses January–December 1995.')
table(['Current volatility tercile','Months','Annual mean momentum'],[
    [label,str(int(g[(g.specification=='vol_t')&(g.regime==label)].iloc[0].n)),f'{g[(g.specification=="vol_t")&(g.regime==label)].iloc[0].momentum_mean_annual_arithmetic:.2%}'] for label in ['Low','Middle','High']
],[2.9,1.1,2.4])
caption('Same source and period. Terciles use full-sample volatility ranks, not real-time trading thresholds. Annualized means are descriptive spreads, not compound strategy returns. The middle tercile outperforms the low tercile, so the relationship is not uniformly decreasing.')
picture('1E_primary_scatter_print.png')
caption(f'Source and period as above; each point is a month and the line is descriptive OLS. Influence diagnostic: omitting the two worst momentum months (January 2001 and April 2009) raises the lagged-model HAC(12) p value from {lag.slope_p_hac_normal:.3f} to {inf.loc[inf.specification=="vol_t_minus_1","slope_p_hac_normal"].iloc[0]:.3f}. This post hoc diagnostic preserves calendar spacing; it is not a cleaned sample or a confirmatory test. Primary results retain all 332 months.')
heading('Sources',2)
linkpara('[1] ','Classroom Excel for Parts 1 and 5, July 2023 FF vintage.','inputs/classroom_part1.xlsx')
linkpara('[2] ','Kenneth French, Fama French Three Factors construction.',FF)
linkpara('[3] ','Kenneth French, Ten Portfolios Formed on Momentum.',MOM)
linkpara('[4] ','Kenneth French, Portfolios Formed on Market Beta.',BETA)
linkpara('[5] ','MSCI Momentum Indexes Methodology, December 2013, pp. 4–10.',MSCI)
caption('Official method pages accessed 19 October 2026; MSCI methodology rechecked 21 October 2026. Classroom inputs are kept unchanged; current website returns are not mixed into the calculations. The MSCI rules cited are the assigned historical version, not a claim about every historical index observation.')

doc.save(ROOT/'Part1_submission.docx')
(ROOT/'Part1_submission.md').write_text('\n'.join(md),encoding='utf-8')
bodywords=sum(len(t.split()) for key,values in content.items() for t in ([values] if isinstance(values,str) else values))
(ROOT/'submission_manifest.json').write_text(json.dumps({'language':'English','main_body_word_count':bodywords,'intended_main_body_pages':2,'intended_exhibit_pages':3,'paper':'US Letter','font':'Times New Roman 11 pt body; 10 pt tables; 9.5 pt captions','numerical_input':'classroom_part1.xlsx, unchanged','new_1C_evidence':dm.to_dict(),'render_status':'pending'},indent=2),encoding='utf-8')

technical=f'''# Part 1 Technical Appendix

This appendix accompanies the concise report module. It retains calculation detail and diagnostics that are not necessary to read the main argument.

## Inputs and transformations

The sole numerical source is `inputs/classroom_part1.xlsx`. FF values are divided by 100; MSCI numeric text is converted to positive USD Gross total-return index levels and month-to-month simple returns. December 1994 levels are retained to form January 1995 returns. No published current-series values replace the classroom vintage. Sample standard deviations use n−1. `audit_manifest.json` records the workbook hash; `review_results.json` records independent raw-input verification.

## Factor definitions and means

SMB averages the returns of the three small size–B/M portfolios and subtracts the three-big average. HML averages small and big high-B/M returns and subtracts the analogous low-B/M average. Market excess return is used directly, not reduced by RF again. Mean tests are ordinary arithmetic-mean tests, as the assignment permits; a price-return CAGR would answer a different question.

Supplementary independent-window normal tests compare later minus earlier means. The size and value p values, 0.484 and 0.185, do not establish a publication-induced decline. Differences in within-period significance are not themselves tests of mean differences.

## Diversification calculations

Each index weight is 0.25. The annual covariance matrix is twelve times the sample monthly covariance matrix. Multiplying it by the weights on both sides gives portfolio variance {dm['portfolio_variance_annual']:.8f} and volatility {mixvol:.6%}. The diagonal variance contribution is {dm['diagonal_variance_component']:.8f}; the off-diagonal covariance contribution is {dm['off_diagonal_covariance_component']:.8f}. Both are variance units, not volatility contributions.

The counterfactual perfectly correlated risk level is the weighted mean of individual volatilities, {meanvol:.6%}. Actual volatility is lower by {(meanvol-mixvol)*100:.6f} percentage points, or {dm['vol_reduction_relative']:.6%} relative. This does not represent the historical volatility of a separate tradable strategy. Factor total-return correlations are distinct from the active-return correlations required by 1D.

Files: `1C_factor_index_return_correlations.csv`, `1C_factor_index_covariance_annual.csv`, `1C_diversification_evidence.csv` and `1C_risk_contributions.csv` in `tables/`. The last file reports weights times marginal variance contributions and their shares; those shares sum to one.

## Return and Sharpe conventions

The primary annualized average is twelve times the arithmetic monthly mean; annual volatility is √12 times the sample monthly standard deviation. CAGR is shown separately. Sharpe follows the question's denominator of strategy-return volatility. RF's literal ratio is zero because it is compared with itself; this should not be interpreted as a meaningful risk-adjusted ranking. Using its own excess-return volatility would instead give 0/0. The mix is monthly rebalanced; there are no implementation costs, taxes or ETF fees. The sample does not separately identify index-launch and backfilled periods.

## Momentum index interpretation

The report follows the assignment-linked December 2013 MSCI document. Positive Z scores govern priority selection; incumbent buffers must also be considered, so positivity should not be asserted for every retained security at every date. The score is 1+Z for positive Z and the reciprocal of 1−Z otherwise. Z-score truncation governs scores and weights, whereas selection uses uncapped Z. The example raw weights precede normalization and issuer caps; they are not final holdings. The official conditional-review rule uses daily market data and does not coincide with the monthly twelve-month-volatility exercise in 1E.

## Volatility timing and inference

The main same-month model is descriptive: its rolling window includes current market returns. The prior-month supplement uses only completed earlier months. Both use December 1995–July 2023, 332 observations. To align the first lagged observation, the classroom FF series supplies December 1994–November 1995. Annualizing the predictor rescales the slope but does not change its significance. A ten-percentage-point rise in annualized volatility changes monthly momentum by about {main.slope*.1*100:.2f} percentage points in the same-month linear fit.

HAC uses a Bartlett kernel with twelve monthly lags and T/(T−2) correction. The p values are asymptotic normal approximations. HAC(3) sensitivity estimates and 95% intervals are in `1E_regressions_HAC.csv`. Full-sample volatility terciles are descriptive, with no causal or implementable real-time interpretation. No bin mean is presented as having passed a separate significance test.

## Post hoc influence diagnostic

Temporarily omitting the two worst momentum months, January 2001 and April 2009, gives:

| Predictor | n | Slope | HAC 12 SE | Approximate p |
| --- | --- | --- | --- | --- |
'''
for row in inf.itertuples():technical+=f'| {row.specification} | {row.n} | {row.slope:.4f} | {row.slope_se_hac:.4f} | {row.slope_p_hac_normal:.4f} |\n'
technical+='''
This is a diagnostic selected after observing the outcome, not a new cleaned sample or a confirmatory test. The original monthly calendar is retained for HAC lag spacing. Full-sample calculations retain both months. The lagged relation stays negative, but the diagnostic p value rises above 0.05; the evidence does not justify strong claims of stable predictability.

## Reproduce

1. Run `python3 scripts/build_part1.py` with numpy, pandas, openpyxl and matplotlib to regenerate numerical results and the detailed HTML.
2. Run `python3 scripts/review_part1.py` to independently check the calculations from raw Excel.
3. Run `python3 scripts/build_submission.py` with python-docx, pandas and its dependencies to rebuild the Word module and this appendix.
4. Convert the Word module with the document renderer and inspect every page before replacing the PDF. PDF layout may vary with Office and font versions.

`Part1_submission.md` contains the report text for merging. Group-wide exhibit numbering and reference numbering may be changed during assembly. The supplied Part 1 module contains no invented cover-page contributions; those belong to the full group report.
'''
(ROOT/'Part1_technical_appendix.md').write_text(technical,encoding='utf-8')
print(json.dumps({'body_words':bodywords,'docx':str(ROOT/'Part1_submission.docx'),'1C_vol_reduction_relative':dm['vol_reduction_relative']},indent=2))
