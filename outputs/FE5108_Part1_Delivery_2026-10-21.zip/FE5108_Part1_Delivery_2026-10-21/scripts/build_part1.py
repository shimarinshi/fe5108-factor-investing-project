"""Offline Part 1 analysis. Numerical inputs: classroom workbook only.
Run: python3 outputs/Part1/scripts/build_part1.py
Dependencies: numpy, pandas, openpyxl, matplotlib. Python >=3.10.
No downloaded factors, simulated data, or prior-project estimates are used.
"""
from pathlib import Path
import os, math, json, hashlib, platform, html, datetime, base64
import numpy as np
import pandas as pd
import openpyxl
os.environ.setdefault('MPLCONFIGDIR', '/tmp/fe5108_part1_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = Path(__file__).resolve().parents[1]
T = ROOT/'tables'; F = ROOT/'figures'
for p in (T,F): p.mkdir(exist_ok=True)
SRC = ROOT/'inputs/classroom_part1.xlsx'
W = openpyxl.load_workbook(SRC, read_only=True, data_only=True)
AUDIT = []
FFURL = 'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html'
MOMURL = 'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_10_port_form_pr_12_2.html'
BETAURL = 'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_port_form_BETA.html'
MSCIURL = 'https://www.msci.com/eqb/methodology/meth_docs/MSCI_Momentum_Indices_Methodology.pdf'
LIBURL = 'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html'
ARCHURL = 'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors_archive.html'

def monthly_key(v):
    return isinstance(v,(int,float)) and float(v).is_integer() and 190001<=v<=210012 and 1<=int(v)%100<=12

def first_monthly_block(sheet, header_row):
    s=W[sheet]; rows=list(s.iter_rows(values_only=True)); data=[]; started=False; first=None; last=None
    for i,r in enumerate(rows[header_row:],header_row+1):
        if monthly_key(r[0]):
            if first is None: first=i
            last=i; started=True; data.append(r)
        elif started: break
    frame=pd.DataFrame(data)
    idx=pd.PeriodIndex([f'{int(v)//100:04d}-{int(v)%100:02d}' for v in frame.pop(0)],freq='M')
    frame.index=idx; frame.index.name='month'
    frame=frame.astype(float)
    assert frame.index.is_unique and frame.index.equals(pd.period_range(idx.min(),idx.max(),freq='M',name='month'))
    assert not frame.isin([-99.99,-999]).any().any() and np.isfinite(frame.to_numpy()).all()
    AUDIT.append(dict(sheet=sheet,excel_rows=f'{first}:{last}',start=str(idx.min()),end=str(idx.max()),months=len(frame),missing=0,duplicates=0,source_units='percent; divide by 100'))
    return frame/100

ff=first_monthly_block('FF - 3 factor returns',4); ff.columns=['Mkt-RF','SMB','HML','RF']
mom_all=first_monthly_block('FF - portfolios sorted on pmom',11)
beta_all=first_monthly_block('FF - portfolios sorted on beta',16)
# original Excel: momentum B=Lo PRIOR, K=Hi PRIOR; beta G=Lo10, P=Hi10.
mom=mom_all[10]-mom_all[1]; mom.name='MOM_decile'
lowbeta=beta_all[6]-beta_all[15]; lowbeta.name='LOWBETA_decile'

levels=[]; raw_dates=[]
for row in W['MSCI - factor totret index'].iter_rows(min_row=8,values_only=True):
    try: d=datetime.datetime.strptime(str(row[0]),'%b %d, %Y')
    except ValueError: continue
    levels.append([pd.Period(d,freq='M'),*[float(str(v).replace(',','')) for v in row[1:6]]]); raw_dates.append(d.date().isoformat())
names=['USA','Value','MinVol','EqualWeight','Momentum']
lev=pd.DataFrame(levels,columns=['month',*names]).set_index('month')
assert lev.index.is_unique and lev.index.equals(pd.period_range('1994-12','2023-07',freq='M',name='month'))
assert (lev>0).all().all() and np.isfinite(lev.to_numpy()).all()
AUDIT.append(dict(sheet='MSCI - factor totret index',excel_rows='8:351',start='1994-12',end='2023-07',months=len(lev),missing=0,duplicates=0,source_units='USD Gross total return index levels; numeric text'))
msci=lev.pct_change(fill_method=None).iloc[1:]
assert len(msci)==343 and msci.index[0]==pd.Period('1995-01')
factors=ff.join(mom).join(lowbeta)
common=ff.loc['1995-01':'2023-07'].join(mom).join(lowbeta).join(msci)
assert len(common)==343 and common.notna().all().all()

def save(df,filename,index=True):
    df.to_csv(T/filename,index=index,float_format='%.12g',encoding='utf-8-sig')

save(ff,'ff3_monthly_decimal.csv'); save(mom.to_frame(),'momentum_decile_spread_monthly_decimal.csv')
save(lowbeta.to_frame(),'lowbeta_decile_spread_monthly_decimal.csv'); save(lev,'msci_levels.csv')
save(pd.DataFrame({'month':lev.index.astype(str),'original_date':raw_dates}),'msci_date_mapping.csv',False)
save(msci,'msci_monthly_returns_decimal.csv'); save(common,'common_monthly_inputs_decimal.csv')
save(pd.DataFrame(AUDIT),'input_audit.csv',False)

# 1A: ordinary mean t statistics; no HAC adjustment, as explicitly allowed.
a_rows=[]
for period,start,end in [('1927-1992','1927-01','1992-12'),('1993-2023Jul','1993-01','2023-07')]:
    for name in ['Mkt-RF','SMB','HML']:
        x=ff.loc[start:end,name]; se=x.std(ddof=1)/np.sqrt(len(x))
        a_rows.append(dict(period=period,factor=name,n=len(x),mean_monthly=x.mean(),mean_annual_arithmetic=12*x.mean(),vol_monthly=x.std(ddof=1),se_mean_monthly=se,t_mean=x.mean()/se,ci95_low_monthly=x.mean()-1.96*se,ci95_high_monthly=x.mean()+1.96*se))
a=pd.DataFrame(a_rows); save(a,'1A_factor_mean_tests.csv',False)
# Additional explicit difference check: large-sample independent-window SE, not a causal publication effect.
diff=[]
for name in ['Mkt-RF','SMB','HML']:
    x=ff.loc['1927-01':'1992-12',name]; y=ff.loc['1993-01':'2023-07',name]
    se=np.sqrt(x.var(ddof=1)/len(x)+y.var(ddof=1)/len(y)); delta=y.mean()-x.mean()
    z=delta/se
    diff.append(dict(factor=name,post_minus_pre_mean_monthly=delta,se_monthly=se,z_large_sample=z,p_two_sided_normal=math.erfc(abs(z)/math.sqrt(2))))
diff=pd.DataFrame(diff); save(diff,'1A_mean_difference_supplement.csv',False)

# 1C: monthly equal-weight mix, rebalanced monthly; arithmetic annualized mean.
rets=msci.copy(); rets['MultiFactor']=rets[['Value','MinVol','EqualWeight','Momentum']].mean(axis=1)
rets['RF']=common['RF']
c=[]
for name,x in rets.items():
    annmean=12*x.mean(); annvol=x.std(ddof=1)*np.sqrt(12)
    sharpe=(annmean-12*rets.RF.mean())/annvol
    # Literal assignment definition gives 0 for RF because the numerator is zero.
    # Its time-series variation is changing bill rates, not risky-asset price volatility.
    c.append(dict(strategy=name,n=len(x),mean_annual_arithmetic=annmean,vol_annual=annvol,sharpe_assignment=sharpe,cagr=np.prod(1+x)**(12/len(x))-1))
c=pd.DataFrame(c).set_index('strategy'); save(c,'1C_performance.csv'); save(rets,'1C_strategy_monthly_returns_decimal.csv')
# Diversification evidence using the same 343 complete monthly observations.
style_names=['Value','MinVol','EqualWeight','Momentum']
style_corr=rets[style_names].corr()
style_cov_annual=12*rets[style_names].cov(ddof=1)
weights=np.full(4,.25)
variance_actual=float(weights@style_cov_annual.to_numpy()@weights)
variance_diagonal=float(np.sum(weights**2*np.diag(style_cov_annual)))
perfect_corr_vol=float(np.dot(weights,np.sqrt(np.diag(style_cov_annual))))
actual_vol=float(np.sqrt(variance_actual))
assert np.isclose(actual_vol,c.loc['MultiFactor','vol_annual'],rtol=1e-12)
div_metrics=pd.DataFrame([
 {'metric':'mean_constituent_vol_and_perfect_positive_correlation_reference','value':perfect_corr_vol},
 {'metric':'multifactor_vol_annual','value':actual_vol},
 {'metric':'vol_reduction_absolute','value':perfect_corr_vol-actual_vol},
 {'metric':'vol_reduction_relative','value':1-actual_vol/perfect_corr_vol},
 {'metric':'portfolio_variance_annual','value':variance_actual},
 {'metric':'diagonal_variance_component','value':variance_diagonal},
 {'metric':'off_diagonal_covariance_component','value':variance_actual-variance_diagonal},
 {'metric':'perfect_positive_correlation_variance_reference','value':perfect_corr_vol**2},
 {'metric':'variance_reduction_relative','value':1-variance_actual/perfect_corr_vol**2},
 {'metric':'minimum_pairwise_total_return_correlation','value':style_corr.to_numpy()[np.triu_indices(4,1)].min()},
 {'metric':'maximum_pairwise_total_return_correlation','value':style_corr.to_numpy()[np.triu_indices(4,1)].max()},
])
save(style_corr,'1C_factor_index_return_correlations.csv')
save(style_cov_annual,'1C_factor_index_covariance_annual.csv')
save(div_metrics,'1C_diversification_evidence.csv',False)
risk_variance_contribution=weights*(style_cov_annual.to_numpy()@weights)
save(pd.DataFrame({'strategy':style_names,'weight':weights,'annual_variance_contribution':risk_variance_contribution,'variance_contribution_fraction':risk_variance_contribution/variance_actual}),'1C_risk_contributions.csv',False)

wealth=(1+rets).cumprod(); wealth=pd.concat([pd.DataFrame(1.,index=pd.PeriodIndex(['1994-12'],freq='M',name='month'),columns=wealth.columns),wealth])
save(wealth,'1C_growth_of_1.csv')

# 1D: active return vs broad market, not vs RF.
active=msci[['Value','MinVol','EqualWeight','Momentum']].sub(msci.USA,axis=0)
academic=common[['HML','SMB','MOM_decile','LOWBETA_decile']]
corr=pd.DataFrame({x:active.apply(lambda y:y.corr(academic[x])) for x in academic})
save(active,'1D_msci_active_returns_decimal.csv'); save(corr,'1D_correlations_4x4.csv')

# 1E: contemporaneous descriptive relation + prior-month information robustness.
# Both specifications use exactly Dec1995-Jul2023; lagged Nov1995 window requires Dec1994.
vol=ff.loc['1995-01':'2023-07','Mkt-RF'].rolling(12,min_periods=12).std(ddof=1)*np.sqrt(12)
vol_lag_full=ff['Mkt-RF'].rolling(12,min_periods=12).std(ddof=1).shift(1)*np.sqrt(12)
e=pd.DataFrame({'momentum':mom,'vol_t':vol,'vol_t_minus_1':vol_lag_full}).loc['1995-12':'2023-07'].copy()
assert len(e)==332 and e.notna().all().all()

def ols_hac(y,x,lags=12,keep=None):
    # Optional exclusions retain the original monthly calendar for HAC lags.
    y_full=np.asarray(y,float);x_full=np.asarray(x,float)
    keep=np.ones(len(x_full),dtype=bool) if keep is None else np.asarray(keep,bool)
    X_full=np.column_stack([np.ones(len(x_full)),x_full])
    y=y_full[keep];x=x_full[keep];X=X_full[keep]
    b=np.linalg.lstsq(X,y,rcond=None)[0]; u=y-X@b; bread=np.linalg.inv(X.T@X)
    scores=np.zeros_like(X_full);scores[keep]=X*u[:,None];meat=scores.T@scores
    for lag in range(1,lags+1):
        gamma=scores[lag:].T@scores[:-lag]
        meat+=(1-lag/(lags+1))*(gamma+gamma.T)
    cov=bread@meat@bread*len(x)/(len(x)-X.shape[1])
    se=np.sqrt(np.diag(cov)); z=b/se
    return dict(n=len(x),intercept=b[0],slope=b[1],slope_se_hac=se[1],slope_z_hac=z[1],slope_p_hac_normal=math.erfc(abs(z[1])/math.sqrt(2)),ci95_low=b[1]-1.96*se[1],ci95_high=b[1]+1.96*se[1],r_squared=1-u@u/np.sum((y-y.mean())**2),correlation=np.corrcoef(x,y)[0,1],lags=lags),X_full@b

er=[]; regimes=[]
for col in ['vol_t','vol_t_minus_1']:
    for l in [3,12]:
        row,fit=ols_hac(e.momentum,e[col],l); er.append({'specification':col,**row})
        if l==12:e['fitted_'+col]=fit
    e['regime_'+col]=pd.qcut(e[col],3,labels=['Low','Middle','High'])
    for reg in ['Low','Middle','High']:
        z=e.loc[e['regime_'+col]==reg]
        regimes.append(dict(specification=col,regime=reg,n=len(z),vol_min=z[col].min(),vol_max=z[col].max(),vol_mean=z[col].mean(),momentum_mean_monthly=z.momentum.mean(),momentum_mean_annual_arithmetic=12*z.momentum.mean(),momentum_vol_annual=z.momentum.std(ddof=1)*np.sqrt(12),momentum_negative_fraction=(z.momentum<0).mean()))
er=pd.DataFrame(er); regimes=pd.DataFrame(regimes)
save(e,'1E_monthly_analysis.csv'); save(er,'1E_regressions_HAC.csv',False); save(regimes,'1E_volatility_terciles.csv',False)
# Post-hoc influence diagnostic; the full-sample primary analysis is unchanged.
excluded=e.momentum.nsmallest(2).index
influence=[]
for col in ['vol_t','vol_t_minus_1']:
    row,_=ols_hac(e.momentum,e[col],12,keep=~e.index.isin(excluded))
    influence.append({'specification':col,'excluded_months':';'.join(str(k) for k in sorted(excluded)),**row})
influence=pd.DataFrame(influence);save(influence,'1E_extreme_month_sensitivity.csv',False)

plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,'figure.dpi':130,'savefig.dpi':200,'font.size':10,'axes.titleweight':'bold'})
palette=['#34495e','#b65c36','#168878','#9580ba','#2178ae','#d49b24','#8b9298']
def finish(fig,name,caption):
    fig.text(.02,.015,caption,fontsize=8,color='#4d5661',ha='left')
    fig.tight_layout(rect=(0,.065,1,1));fig.savefig(F/(name+'.png'),bbox_inches='tight');fig.savefig(F/(name+'.svg'),bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(11,4.4))
for k,period in enumerate(a.period.unique()):
    z=a[a.period==period]; xpos=np.arange(3)+(k-.5)*.34
    axs[0].bar(xpos,z.mean_annual_arithmetic*100,.32,label=period,color=palette[k])
    axs[1].bar(xpos,z.t_mean,.32,label=period,color=palette[k])
for ax in axs:ax.set_xticks(range(3),['Mkt-RF','SMB','HML']);ax.axhline(0,color='black',lw=.7)
axs[0].set(ylabel='Arithmetic annualized mean (%)',title='1A | Average factor spreads')
axs[1].set(ylabel='Ordinary t statistic of mean',title='1A | Statistical evidence')
axs[1].axhline(1.96,color='#b65c36',ls='--',label='1.96 reference');axs[0].legend(fontsize=8);axs[1].legend(fontsize=8)
finish(fig,'1A_premia_and_tstats','Source: classroom FF3; US published factor spreads. 1927-1992 (792 months), 1993-Jul2023 (367). No HAC.')
fig,axs=plt.subplots(1,2,figsize=(12,4.8));ix=np.arange(len(c)); labels=['USA','Value','MinVol','Equal\nWeight','Momentum','Multi\nFactor','RF']
axs[0].bar(ix,c.mean_annual_arithmetic*100,color=palette);axs[1].bar(ix,c.sharpe_assignment,color=palette)
for ax in axs:ax.set_xticks(ix,labels,rotation=25,ha='right');ax.axhline(0,color='black',lw=.7)
axs[0].set(title='1C | Arithmetic average return',ylabel='Annualized mean (%)');axs[1].set(title='1C | Assignment Sharpe ratio',ylabel='Sharpe (strategy volatility denominator)')
finish(fig,'1C_returns_and_sharpe','Source: classroom MSCI USA large/mid-cap Gross USD indices + FF RF. Jan1995-Jul2023, 343 months. RF ratio=0 literally.')
# Print-sized chart with labels intended for insertion at 6.7 inches wide.
fig,ax=plt.subplots(figsize=(6.7,2.7))
bar_names=['Value','MinVol','EqualWeight','Momentum','MultiFactor','Corr = 1\nreference']
bar_values=[*c.loc[style_names,'vol_annual'],actual_vol,perfect_corr_vol]
bars=ax.bar(bar_names,np.array(bar_values)*100,color=[palette[1],palette[2],palette[3],palette[4],palette[5],'#c2c8ce'])
for bar,v in zip(bars,bar_values):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+.3,f'{v:.2%}',ha='center',fontsize=9)
ax.set(ylabel='Annualized volatility (%)',ylim=(0,20),title='Diversification reduces risk despite high correlations')
fig.tight_layout();fig.savefig(F/'1C_diversification_risk.png',dpi=250,bbox_inches='tight');fig.savefig(F/'1C_diversification_risk.svg',bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(6.7,2.8))
ax.scatter(e.vol_t*100,e.momentum*100,s=15,alpha=.55,color='#2178ae')
order=np.argsort(e.vol_t.to_numpy());ax.plot(e.vol_t.iloc[order]*100,e.fitted_vol_t.iloc[order]*100,color='#b65c36',lw=1.8)
ax.axhline(0,color='black',lw=.6)
ax.set(xlabel='Trailing 12-month market volatility (annualized %)',ylabel='Monthly momentum spread (%)',title='Weak negative linear association in this sample')
chart_stats=pd.read_csv(T/'1E_regressions_HAC.csv');chart_stats=chart_stats[(chart_stats.specification=='vol_t')&(chart_stats.lags==12)].iloc[0]
ax.set_title('Weak negative linear association in this sample',pad=23)
ax.text(.98,1.02,f'n = {len(e)}; R² = {chart_stats.r_squared:.1%}; HAC(12) p = {chart_stats.slope_p_hac_normal:.3f}',transform=ax.transAxes,ha='right',va='bottom',fontsize=8)
fig.tight_layout();fig.savefig(F/'1E_primary_scatter_print.png',dpi=250,bbox_inches='tight');fig.savefig(F/'1E_primary_scatter_print.svg',bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(10,5))
for i,col in enumerate(wealth):ax.plot(wealth.index.to_timestamp(),wealth[col],label=col,color=palette[i],lw=2 if col=='MultiFactor' else 1.25)
ax.set(yscale='log',title='1C | Growth of USD 1 (supplement)',ylabel='Cumulative wealth (log scale)',xlabel='Month');ax.legend(ncol=4,fontsize=9)
finish(fig,'1C_cumulative_wealth','Source: classroom MSCI Gross USD + FF RF; Dec1994 base through Jul2023. Four-index mix reset to 25% monthly; no costs.')
fig,ax=plt.subplots(figsize=(8,4.6));im=ax.imshow(corr,vmin=-1,vmax=1,cmap='RdBu_r',aspect='auto')
ax.grid(False);ax.set_xticks(range(4),['HML','SMB','Momentum\ndecile spread','Low-beta\ndecile spread']);ax.set_yticks(range(4),corr.index)
for i in range(4):
    for j in range(4):ax.text(j,i,f'{corr.iloc[i,j]:.3f}',ha='center',va='center',color='white' if abs(corr.iloc[i,j])>.6 else '#202b36')
ax.set_title('1D | MSCI active returns vs academic spreads');fig.colorbar(im,ax=ax,label='Pearson correlation')
finish(fig,'1D_correlation_heatmap','Source: classroom MSCI/FF; Jan1995-Jul2023, n=343 each cell. MSCI returns less USA; all academic legs value-weighted.')
fig,axs=plt.subplots(1,2,figsize=(11,4.8))
for ax,col,label in zip(axs,['vol_t','vol_t_minus_1'],['Same-month descriptive','Prior-month information']):
    ax.scatter(e[col]*100,e.momentum*100,s=14,alpha=.5,color='#2178ae')
    order=np.argsort(e[col].to_numpy());ax.plot(e[col].iloc[order]*100,e['fitted_'+col].iloc[order]*100,color='#b65c36',lw=2)
    ax.axhline(0,color='black',lw=.6);ax.set(title=label,xlabel='Trailing 12-month market volatility (annualized %)',ylabel='Momentum spread, monthly (%)')
finish(fig,'1E_volatility_scatter','Source: classroom FF Mkt-RF + value-weighted momentum deciles. Dec1995-Jul2023, n=332. Lines: OLS, not causality.')
fig,axs=plt.subplots(1,2,figsize=(10,4.5))
for ax,col,label in zip(axs,['vol_t','vol_t_minus_1'],['Same-month volatility','Prior-month volatility']):
    z=regimes[regimes.specification==col];ax.bar(z.regime,z.momentum_mean_annual_arithmetic*100,color=[palette[2],palette[4],palette[1]])
    ax.axhline(0,color='black',lw=.7);ax.set(title=label,xlabel='Full-sample volatility tercile',ylabel='Momentum annualized arithmetic mean (%)')
finish(fig,'1E_volatility_regimes','Source: classroom FF; Dec1995-Jul2023. Terciles are descriptive full-sample bins, not implementable real-time thresholds.')

# Independent numerical and source-shape checks, rather than mirrored unit tests.
checks={}
checks['1A_expected_n']=a.n.tolist()==[792,792,792,367,367,367]
checks['1A_t_matches_intercept_OLS']=True
for row in a.itertuples():
    start,end=('1927-01','1992-12') if row.period=='1927-1992' else ('1993-01','2023-07')
    x=ff.loc[start:end,row.factor].to_numpy(); u=x-x.mean()
    assert np.isclose(row.t_mean, x.mean()/np.sqrt((u@u/(len(x)-1))/len(x)))
checks['MSCI_343_returns']=len(msci)==343
checks['MSCI_reconstruction_max_error']=float(np.max(np.abs(((1+msci).cumprod()*lev.iloc[0]/lev.iloc[1:])-1)))
assert checks['MSCI_reconstruction_max_error']<1e-12
checks['multifactor_weighted_sum_max_error']=float(abs(rets.MultiFactor-(msci.Value+msci.MinVol+msci.EqualWeight+msci.Momentum)/4).max())
checks['1D_independent_matrix_max_error']=float(abs(corr.to_numpy()-np.corrcoef(np.column_stack([active.to_numpy(),academic.to_numpy()]).T)[:4,4:]).max())
assert checks['1D_independent_matrix_max_error']<1e-12
checks['1E_expected_n']=len(e)==332
first=e.iloc[0]; assert np.isclose(first.vol_t,ff.loc['1995-01':'1995-12','Mkt-RF'].std(ddof=1)*np.sqrt(12))
assert np.isclose(first.vol_t_minus_1,ff.loc['1994-12':'1995-11','Mkt-RF'].std(ddof=1)*np.sqrt(12))
checks['1E_window_boundaries_verified']=True
# HAC L=0 is independently HC1; slope = corr(y,x)*sd(y)/sd(x).
for col in ['vol_t','vol_t_minus_1']:
    row,_=ols_hac(e.momentum,e[col],0)
    assert np.isclose(row['slope'],e.momentum.corr(e[col])*e.momentum.std()/e[col].std())
    # Independent scalar projection of HAC slope variance, without matrix sandwich.
    xx=e[col].to_numpy(); yy=e.momentum.to_numpy(); xc=xx-xx.mean()
    slope=xc@(yy-yy.mean())/(xc@xc); residual=yy-yy.mean()-slope*xc
    score=xc*residual; scalar_meat=score@score
    for lag in range(1,13):scalar_meat+=2*(1-lag/13)*(score[lag:]@score[:-lag])
    independent_se=np.sqrt(scalar_meat/(xc@xc)**2*len(xx)/(len(xx)-2))
    row,_=ols_hac(yy,xx,12)
    assert np.isclose(row['slope_se_hac'],independent_se,rtol=1e-12)
checks['1E_slope_crosscheck']=True
checks['1E_HAC_scalar_projection_crosscheck']=True
assert np.isfinite(a.select_dtypes('number')).all().all() and np.isfinite(c).all().all() and np.isfinite(corr).all().all()
checks['finite_all_summary_outputs']=True
checks['1C_covariance_portfolio_vol_verified']=bool(np.isclose(actual_vol,c.loc['MultiFactor','vol_annual']))
checks['1C_risk_contributions_sum_verified']=bool(np.isclose(risk_variance_contribution.sum(),variance_actual))
manifest={'numerical_source':'inputs/classroom_part1.xlsx only','original_path':'inputs/classroom_part1.xlsx','source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'assignment_sha256':hashlib.sha256((ROOT/'inputs/assignment.pdf').read_bytes()).hexdigest(),'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'openpyxl':openpyxl.__version__,'matplotlib':matplotlib.__version__,'methods_access_date':'2026-10-19','msci_methodology_version':'December 2013, assignment URL; not asserted valid over entire return history','sources':[FFURL,MOMURL,BETAURL,MSCIURL,LIBURL,ARCHURL],'checks':checks}
(ROOT/'audit_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')

def table(df,percent_cols=(),digits=3):
    z=df.copy()
    for col in z:
        if col in percent_cols:z[col]=z[col].map(lambda v:f'{v*100:.{digits}f}%')
        elif pd.api.types.is_float_dtype(z[col]):z[col]=z[col].map(lambda v:f'{v:.{digits}f}')
    labels={'period':'样本期间','factor':'因子','n':'月数','mean_monthly':'月均值','mean_annual_arithmetic':'年化算术均值','t_mean':'均值t值','post_minus_pre_mean_monthly':'后段−前段月均值','se_monthly':'差值标准误','z_large_sample':'差值z值','p_two_sided_normal':'双侧近似p值','strategy':'策略','vol_annual':'年化波动率','sharpe_assignment':'题目口径Sharpe','cagr':'CAGR','specification':'波动率变量','slope':'斜率','slope_se_hac':'HAC标准误','slope_z_hac':'HAC z值','slope_p_hac_normal':'近似p值','r_squared':'R²','lags':'HAC滞后阶数','regime':'波动组','vol_min':'组内最小波动率','vol_max':'组内最大波动率','vol_mean':'组内平均波动率','momentum_mean_monthly':'动量月均值','momentum_mean_annual_arithmetic':'动量年化均值','momentum_vol_annual':'动量年化波动率','momentum_negative_fraction':'动量负收益占比','sheet':'工作表','excel_rows':'Excel行','start':'起始月','end':'结束月','months':'月数','missing':'缺失数','duplicates':'重复数','source_units':'原始单位','excluded_months':'诊断排除月份','Question / location':'问题与页码','Paraphrased answer':'方法转述'}
    return z.rename(columns=labels).to_html(index=False,border=0,escape=True,classes='data')
def fig(name,caption):
    encoded=base64.b64encode((F/(name+'.png')).read_bytes()).decode('ascii')
    return f'<figure><img src="data:image/png;base64,{encoded}" alt="{html.escape(caption)}"><figcaption>{caption}</figcaption></figure>'
def ref(url,label):return f'<a href="{url}">{label}</a>'
before=a[a.period=='1927-1992'].set_index('factor');after=a[a.period=='1993-2023Jul'].set_index('factor')
rank=c.drop('RF');bestret=rank.mean_annual_arithmetic.idxmax();worstret=rank.mean_annual_arithmetic.idxmin();bestsh=rank.sharpe_assignment.idxmax();worstsh=rank.sharpe_assignment.idxmin()
atab=a[['period','factor','n','mean_monthly','mean_annual_arithmetic','t_mean']]
ctab=c.reset_index()
etab=er[['specification','n','slope','slope_se_hac','slope_z_hac','slope_p_hac_normal','r_squared','lags']]
pieces=[]
pieces.append('''<header><div class="eyebrow">FE5108 · Practitioner segment · Part 1 / 22 points</div><h1>因子投资：计算、方法与结果</h1><p>课堂数据版本 · 1A–1E 完整工作稿 · 2026-10-19</p></header>
<div class="note"><b>使用范围：</b>这是可供小组审阅与整合的 Part 1 分析稿，不是整份作业的最终提交版。全部数值仅来自附带的课堂 Excel；官方网页仅支持方法解释。未加入交易成本、费用或税后调整。</div>
<nav><a href="#A">1A 因子溢价</a><a href="#B">1B 指数方法</a><a href="#C">1C 分散化</a><a href="#D">1D 构建敏感性</a><a href="#E">1E 波动率状态</a><a href="#sources">来源与复算</a></nav>''')
pieces.append('''<section><h2>统一口径与数据验证</h2><p>FF 数值按百分数读取后除以100；MSCI 为USD、Gross总收益指数水平，清除千分位后计算 Iₜ/Iₜ₋₁−1。保留1994年12月起始水平，得到1995年1月–2023年7月的343个月收益。日期统一到收益发生的年月，实际月末交易日映射保存在表中。</p><p>收益平均值使用算术平均；年化均值=12×月均值，年化波动率=√12×月度样本标准差（ddof=1）。CAGR单列参考，不用于均值检验或主要Sharpe排名。所有相关性使用相同的完整样本，不做静默填零或插值。</p>'''+table(pd.DataFrame(AUDIT))+'''<p>FF动量取首个市值加权月度区块的 K−B；低beta取对应区块 G−P。后续等权、年度、股票数量等区块全部排除。beta中间分位标题存在日期格式转换，使用两端原始标记与固定列映射。所需月度区块未发现空值、重复月份或缺失标记。</p></section>''')
pieces.append('<section id="A"><h2>1A · 因子溢价与发表前后差异</h2><p>分别检验每条因子的月度总体均值是否为零：t=月均值÷(样本标准差/√T)。采用普通均值t值，按题意不进行Newey–West修正。收益价差不是一条独立、完全投资的资产净值，不对它取几何平均来检验溢价。</p>'+table(atab,['mean_monthly','mean_annual_arithmetic'])+fig('1A_premia_and_tstats','图1A：三个因子在两段样本中的算术年化均值和普通t值。1.96为大样本双侧5%参考线；精确临界值略有差异。'))
for name in ['Mkt-RF','SMB','HML']:
    b0=before.loc[name];a0=after.loc[name]
    pieces.append(f'<p><b>{name}：</b>平均月度溢价由 {b0.mean_monthly:.3%} 变为 {a0.mean_monthly:.3%}；t值由 {b0.t_mean:.2f} 变为 {a0.t_mean:.2f}。后段样本'+('仍有显著正均值的统计证据。' if a0.t_mean>1.97 else '不足以在常用双侧5%水平拒绝零均值。')+'</p>')
pieces.append('<p>统计显著性变化不是均值差异本身的显著性检验。附表另列“后段−前段”均值差及独立样本大样本标准误；它不控制宏观状态，也不识别论文发表的因果效应。样本长度不同、收益波动和溢价大小都影响t值。历史不显著不等于没有溢价；历史显著也不等于未来高确信度或扣成本后可获利。</p>'+table(diff,['post_minus_pre_mean_monthly','se_monthly'])+f'<p>SMB与HML来自按市值和B/M划分的六个市值加权组合；HML是在小盘、大盘中分别比较高低B/M后平均，不是全市场十分位价差。Mkt−RF已扣RF，不能重复扣除。方法：{ref(FFURL,"FF3官方说明")}。</p><p>用于后续的动量=MOM最高十分位−最低十分位；低beta=最低beta十分位−最高beta十分位，均用市值加权腿。动量按此前第2–12个月收益每月分组，beta在6月底按过去最多60、至少24个月收益估计后分组。方法：'+ref(MOMURL,'动量十分位')+'；'+ref(BETAURL,'Beta组合')+'。不使用官网现成2×3 Mom替代十分位动量。</p></section>')

pieces[-1]=pieces[-1].replace('</section>','<p><b>投资确信度：</b>不能将三个因子都描述为同等高确信度的机会：后段市场溢价仍显著，SMB/HML的均值证据较弱。但补充均值差检验的p值为SMB 0.484、HML 0.185，均未达到5%水平；因此不能宣称“溢价下降已被统计证明”，更不能归因于论文发表。</p></section>')

# Source-derived methodology kept concise (~190 English words); benefits are explicitly our inference.
method_rows=[
('Universe (p.4)','MSCI USA parent constituents: large- and mid-cap US equities.'),
('Signal (p.4)','Combine six- and twelve-month local price gains excluding the latest month, less local risk-free rates; scale by three-year weekly-return volatility.'),
('Standardization (p.4)','Standardize each signal, average equally, restandardize, clip Z to ±3. Scores: 1+Z if Z>0; (1−Z)⁻¹ otherwise.'),
('Selection (pp.5–8)','Select highest positive uncapped Z scores toward a fixed count, reviewed for coverage. Parent weights break ties; buffers retain incumbents.'),
('Weights (p.5)','Normalize parent capitalization weight × momentum score, then apply issuer limits.'),
('Regular review (p.6)','May and November month-end; corporate-event maintenance also applies.'),
('Conditional review (p.10)','Monthly monitoring compares the parent’s three-month daily-return volatility increase with the reference-history 95th percentile; USA uses World as reference. Triggered reviews use only six-month momentum, aiming to mitigate volatility-spike drawdowns.'),
('Cap (p.9)','USA issuer weight is limited to 5%; this is issuer-level, not necessarily share-class-level.')]
pieces.append('<section id="B"><h2>1B · MSCI Momentum 方法说明</h2><p>以下按题目链接实际返回的<b>December 2013</b>版本转述，并注明PDF页码。它是题目指定的方法依据，不能证明1995–2023年间规则完全不变，也不等于最新现行规则。数值计算直接使用课堂指数，不重新构造成分股。</p>'+table(pd.DataFrame(method_rows,columns=['Question / location','Paraphrased answer']))+f'<p>Official source: {ref(MSCIURL,"MSCI Momentum Indexes Methodology, December 2013")}（访问2026-10-19）。</p><p><b>对市值参与加权的分析：</b>好处一，大市值股票通常交易承载能力较强，有利于组合容量；好处二，减轻对小盘、强信号股票的过度押注。潜在坏处是稀释纯动量暴露，同时可能保留大盘集中风险。这些是我们对权重设计的推论，而非收益保证。半年调仓在信号更新与换手成本间折中；缓冲机制也服务于稳定性。</p><p>临时调整细节：在月末前第9个营业日检查，波动率使用截至前一月末的三个月日收益；比较的是波动率的月度<b>相对变化</b>，不是波动率绝对水平。1E仅有月度数据且用12个月窗口，因此不声称复制这一触发机制。</p></section>')

pieces[-1]=pieces[-1].replace('</section>','<p><b>从信号到持仓：</b>先测量价格动量并作风险调整，再标准化、选择股票，最后把分数与母指数权重相乘并归一化、执行上限。若A在母指数占2%、分数1.5，B占1%、分数2，则原始权重分别为0.03与0.02；最终归一化和上限之前，A的配置输入仍较大。这说明分数较高不保证权重较高，市值也参与了组合设计。</p></section>')
pieces.append('<section id="C"><h2>1C · 因子分散化与绩效</h2><p>多因子每月收益=(Value+MinVol+EqualWeight+Momentum)/4，即每月重新配置为四指数各25%。Sharpe严格按题目脚注：(算术年化策略均值−算术年化RF均值)/策略年化波动率；不是以超额收益波动率为分母。</p>'+table(ctab,['mean_annual_arithmetic','vol_annual','cagr'])+fig('1C_returns_and_sharpe','图1C：美国大中盘市场、四个因子指数、多因子组合和RF；1995年1月–2023年7月，343个月。')+f'<p>在六个权益组合中，算术平均收益最高的是 <b>{bestret}</b>，最低的是 <b>{worstret}</b>；Sharpe最高的是 <b>{bestsh}</b>，最低的是 <b>{worstsh}</b>。多因子年化平均收益 {c.loc["MultiFactor","mean_annual_arithmetic"]:.2%}、波动率 {c.loc["MultiFactor","vol_annual"]:.2%}、Sharpe {c.loc["MultiFactor","sharpe_assignment"]:.3f}；对照USA分别为 {c.loc["USA","mean_annual_arithmetic"]:.2%}、{c.loc["USA","vol_annual"]:.2%}、{c.loc["USA","sharpe_assignment"]:.3f}。</p><p>分散化不能保证收益超过表现最好的单因子。四指数仍共同持有美国股票，多因子并非市场中性；平均收益恰为四者平均，风险则取决于协方差。这里的收益为Gross指数历史，未扣基金费用、交易费用与税；样本未区分指数推出前回溯收益，不视为全部可实时实现。</p><p><b>RF的特殊处理：</b>按题目字面公式，RF减自身的均值为0，时间变化的短票利率序列标准差为正，所以表中比率为0。这是公式结果，不能把它解释成无风险投资的有意义风险调整排名；该波动也不等于单月已知票据收益的价格风险。若按RF自身超额收益的波动率定义，则为0/0、应标N/A。</p>'+fig('1C_cumulative_wealth','补充图：1994年12月底投入1美元的累计净值，纵轴为对数。CAGR用于复利财富比较，与主表算术平均收益分开。')+'</section>')
pieces[-1]=pieces[-1].replace('</section>',f'<h3>分散化证据</h3><p>四个因子指数原始收益两两相关性介于 {style_corr.to_numpy()[np.triu_indices(4,1)].min():.3f} 与 {style_corr.to_numpy()[np.triu_indices(4,1)].max():.3f}，共同市场风险仍很强。用同一年度协方差矩阵计算组合风险：σ²=wᵀΣw，w为四个25%权重。四者波动率的加权平均为 {perfect_corr_vol:.2%}；在相关性全部等于1且各自波动率不变的参考情形，组合波动率也等于该值。实际组合波动率为 {actual_vol:.2%}，较参考值降低 {(perfect_corr_vol-actual_vol)*100:.2f}个百分点、相对降低 {(1-actual_vol/perfect_corr_vol):.2%}。这量化了不完全相关的分散化收益，但不是相对可交易策略的超额收益。</p>'+table(style_corr.reset_index().rename(columns={'index':'MSCI factor index'}))+fig('1C_diversification_risk','补充分散化图：美国大中盘四因子指数；1995年1月–2023年7月，343个月，Gross USD。灰色柱为相关性全为1的解析参考，并非另一条策略回测。')+'<p>多因子仍比MinVol单独持有的波动率高。因此结论是组合降低了平均单因子的风险，并在本样本改善相对USA的Sharpe；不声称它在所有单因子之间占优。年度协方差、方差贡献和所有指标另存于CSV。</p></section>')
pieces[-1]=pieces[-1].replace('</section>','<p><b>排名解释：</b>Momentum的Sharpe约0.686、MinVol约0.683，差距仅约0.003；这里只能报告本样本数值排名，尚未检验两者的绩效差异显著性，不能据此断言动量稳定优于低波动率。</p></section>')
pieces.append('<section id="D"><h2>1D · 因子构建方式的敏感性</h2><p>每个MSCI因子收益先减当月MSCI USA收益，再与FF侧四条价差做Pearson相关性。所有单元格均用1995年1月–2023年7月的343个月，不把多头指数原始收益与多空价差直接比较。</p>'+table(corr.reset_index().rename(columns={'index':'MSCI active return'}))+fig('1D_correlation_heatmap','图1D：行是MSCI因子相对USA的主动收益，列是学术收益价差。')+f'<p>预期对应关系的相关性为：Value–HML <b>{corr.loc["Value","HML"]:.3f}</b>，EqualWeight–SMB <b>{corr.loc["EqualWeight","SMB"]:.3f}</b>，Momentum–十分位动量 <b>{corr.loc["Momentum","MOM_decile"]:.3f}</b>，MinVol–低beta价差 <b>{corr.loc["MinVol","LOWBETA_decile"]:.3f}</b>。</p><p>这些对应不是定义上的等价：等权并非直接只持有小盘；最小波动率关注方差和协方差，低beta关注与市场的协动；FF HML与MSCI Value的投资范围、价值定义、权重与调仓规则也可不同。相关性说明收益共同变化，不能证明因子完全相同、独立因果来源或未来稳定性。</p></section>')
pieces[-1]=pieces[-1].replace('</section>','<p><b>相似性判断：</b>四组预期对应中，MinVol与低beta的样本相关性最高；EqualWeight与SMB最低，说明等权指数不能直接当成学术规模因子的替代品。EqualWeight与HML的相关性0.431还高于其与SMB的0.322，提示收益存在交叉风格共同变化，不能把相关性表解读成纯因子归属。</p></section>')
pieces.append('<section id="E"><h2>1E · 动量收益与近期市场波动率</h2><p>主分析采用σₜ=√12×sd(Mkt−RFₜ₋₁₁,…,Mkt−RFₜ)，从1995年12月开始。同期OLS：MOMₜ=a+bσₜ+εₜ，描述同期关联。补充模型用σₜ₋₁，避免解释变量包含当月市场收益。为使两个模型同为332个月，补充模型首个窗口用1994年12月–1995年11月的课堂FF数据；主模型仍严格从1995年1月开始构建。</p><p>波动率和动量均为小数收益口径；斜率b表示年化波动率提高1.00（100个百分点）对应的月动量收益变化。提高10个百分点的效应为0.1b。滚动窗口重叠，主推断使用Bartlett核Newey–West HAC(12)，乘T/(T−2)有限样本校正；并列HAC(3)敏感性。p值为双侧渐近正态近似，不是有限样本精确t检验。</p>'+table(etab,digits=4)+fig('1E_volatility_scatter','图1E-1：月动量收益与同期/前一期市场波动率；同一332个月。')+table(regimes,['vol_min','vol_max','vol_mean','momentum_mean_monthly','momentum_mean_annual_arithmetic','momentum_vol_annual','momentum_negative_fraction'])+fig('1E_volatility_regimes','图1E-2：按全样本波动率三分位分组的平均动量收益。分组阈值是事后描述，不是实时交易规则。'))
for col,label in [('vol_t','同期'),('vol_t_minus_1','滞后一期')]:
    row=er[(er.specification==col)&(er.lags==12)].iloc[0]
    pieces.append(f'<p><b>{label}结果：</b>相关系数 {row.correlation:.3f}，斜率 {row.slope:.4f}，市场年化波动率高10个百分点对应月动量收益约变化 <b>{row.slope*.1*100:.2f}个百分点</b>（绝对收益差，不是相对百分比）；HAC(12)的z={row.slope_z_hac:.2f}，p={row.slope_p_hac_normal:.4f}，R²={row.r_squared:.2%}。'+('在5%渐近水平有线性关系的统计证据。' if row.slope_p_hac_normal<.05 else '在5%渐近水平没有足够的线性关系证据。')+'</p>')
for col,label in [('vol_t','同期'),('vol_t_minus_1','滞后')]:
    g=regimes[regimes.specification==col].set_index('regime')
    pieces.append(f'<p>{label}三分位中，低、中、高波动组的动量年化算术均值分别为 {g.loc["Low","momentum_mean_annual_arithmetic"]:.2%}、{g.loc["Middle","momentum_mean_annual_arithmetic"]:.2%}、{g.loc["High","momentum_mean_annual_arithmetic"]:.2%}。中间组高于低波动组，不能把整体负斜率理解为全区间单调递减。</p>')
pieces.append('<h3>补充：极端月份影响诊断</h3><p>事后仅为诊断影响，暂时排除全样本中动量收益最低的2001年1月和2009年4月，再估计HAC(12)模型。主分析仍保留全部332个月，既不清洗掉危机收益，也不把这项按结果选择月份的检验作为确认性推断。HAC计算保留原始月历，未把被排除月份两侧错误连接为相邻月份。</p>'+table(influence[['specification','excluded_months','n','slope','slope_se_hac','slope_p_hac_normal','r_squared']],digits=4))
rr=influence[influence.specification=='vol_t_minus_1'].iloc[0]
pieces.append(f'<p>排除这两个月后，滞后模型仍为负斜率，但近似参考p值变为 {rr.slope_p_hac_normal:.3f}，不再低于0.05。这说明其显著性对极端收益有敏感性；不是证明负相关不存在，而是限制对稳定预测能力的宣称。</p>')
pieces.append('<p>负斜率仅描述线性条件平均关系，不代表每个高波动月份都亏损。低R²意味着单个波动率指标解释能力有限；线性模型可能遗漏非线性与危机反弹等状态。三分位结果是补充描述，没有控制混杂因素。即便滞后结果显著，也只是本样本内预测关联，不能证明因果或样本外策略获利，更不能据此验证MSCI临时调仓机制。</p></section>')
pieces.append('<section id="sources"><h2>来源、复算与边界</h2><ul><li>数值源：inputs/classroom_part1.xlsx（原始课堂文件只读副本）；SHA256：<code>'+manifest['source_sha256']+'</code>。</li><li>题目：inputs/assignment.pdf；仅完成Part 1，未生成虚构成员贡献。</li><li>FF3、动量与beta方法：'+ref(FFURL,'FF3')+' / '+ref(MOMURL,'Momentum deciles')+' / '+ref(BETAURL,'Beta portfolios')+'。</li><li>MSCI方法：'+ref(MSCIURL,'December 2013 PDF，题目指定链接')+'；来源访问日期2026-10-19。</li><li>官网说明历史值可能修订，2025年起FIZ转CIZ。我们未以官网当前数据替换课堂202307版；也未声称已与历史存档逐值匹配。'+ref(LIBURL,'更新说明')+'；'+ref(ARCHURL,'历史存档')+'。</li></ul><p>复算：在任意目录运行 <code>python3 /完整路径/Part1/scripts/build_part1.py</code>。依赖numpy、pandas、openpyxl、matplotlib；离线读取包内Excel，重写本目录结果。每张图有PNG和SVG；所有计算中间序列与汇总见tables/，单位以列名及本文为准。</p><p>已验证：样本长度、连续月份、缺失标记、指数收益逆向重建、等权多因子恒等式、1A截距OLS等价、相关矩阵独立计算及1E窗口边界。详细结果见audit_manifest.json。尚未独立认证课堂底层供应商数据，也未复刻指数成分历史。</p></section>')
css='''body{font:16px/1.75 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif;color:#233344;background:#f3f5f7;margin:0}main{max-width:1120px;margin:30px auto;background:white;padding:42px 48px}header{border-bottom:4px solid #168878;padding-bottom:18px}h1{font-size:34px;line-height:1.3;margin:10px 0}h2{font-size:24px;margin-top:36px;color:#174e68}.eyebrow{font-size:12px;letter-spacing:1px;color:#168878}p{margin:12px 0}a{color:#166f8d}nav{display:flex;gap:18px;flex-wrap:wrap;margin:24px 0}table{border-collapse:collapse;width:100%;font-size:12px;line-height:1.5;margin:20px 0}th{background:#174e68;color:white;text-align:left;padding:9px}td{padding:8px;border-bottom:1px solid #dce3e8}tr:nth-child(even){background:#f3f6f8}figure{margin:28px 0}figure img{width:100%;height:auto}figcaption{font-size:12px;color:#5a6570}.note{padding:15px 20px;background:#eaf5f2;margin:22px 0}code{font-size:12px;overflow-wrap:anywhere}section{overflow-x:auto}@media print{body{background:white}main{margin:0;padding:12px;max-width:none}nav{display:none}h2{break-after:avoid}figure,table{break-inside:avoid}a{color:inherit}p{orphans:3;widows:3}}'''
(ROOT/'Part1_report.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FE5108 Part 1</title><style>'+css+'</style><main>'+''.join(pieces)+'</main></html>',encoding='utf-8')

readme=f'''# FE5108 Part 1：计算与方法包

打开 `Part1_report.html` 阅读完整中文报告（英文图表与原始字段名）。本目录已完成1A–1E；这是工作稿，需与Part 2及后续内容整合，不是整份作业的最终提交件。

## 文件
- `Part1_report.html`：中文详细计算报告；图像内嵌，可单独复制浏览。
- `Part1_submission.docx` 与 `Part1_submission.pdf`：可并入小组作业的英文正文与展表。
- `Part1_submission.md`：相同正文的可复制文本及展表内容。
- `Part1_technical_appendix.md`：正文之外的方法细节与影响诊断。
- `tables/`：UTF-8 CSV，保存原始抽取序列、中间计算和结果；月度收益全部以小数保存。
- `figures/`：8组图，PNG高清版与SVG矢量版；新增分散化风险对照与适合打印的主散点图。
- `inputs/`：课堂Excel与题目只读副本，不使用旧项目或网络更新收益。
- `scripts/build_part1.py`：离线复算；会重写本包输出，不修改输入。
- `audit_manifest.json`：数据哈希、运行版本和核验结果。
- `README_MERGE.md`：交付包合并与复现说明。
- `scripts/review_part1.py` 与 `review_results.json`：从原始Excel独立复算；不调用主程序或依赖中间计算序列。

## 复算
依赖：Python≥3.10，numpy、pandas、openpyxl、matplotlib。
运行：`python3 scripts/build_part1.py`（从Part1目录）；脚本也支持任意目录用绝对路径运行。

## 主要发现
- 1A：后段Mkt−RF t={after.loc['Mkt-RF','t_mean']:.2f}，SMB t={after.loc['SMB','t_mean']:.2f}，HML t={after.loc['HML','t_mean']:.2f}。不能把“后段不显著”写成“因子已被证明无效”。
- 1C：权益组合中算术年化收益最高{bestret}；Sharpe最高{bestsh}。多因子Sharpe={c.loc['MultiFactor','sharpe_assignment']:.3f}，USA={c.loc['USA','sharpe_assignment']:.3f}。
- 1D：Value/HML={corr.loc['Value','HML']:.3f}；EqualWeight/SMB={corr.loc['EqualWeight','SMB']:.3f}；Momentum/十分位动量={corr.loc['Momentum','MOM_decile']:.3f}；MinVol/低beta={corr.loc['MinVol','LOWBETA_decile']:.3f}。
- 1E：完整的HAC(12)、HAC(3)、同期/滞后关系和分组结果见报告与表格；不作因果或样本外获利声明。

## 关键约定
1. FF百分数÷100；MSCI Gross USD水平转月收益。1994年12月只作为初始水平。
2. 主平均收益=月均值×12；CAGR单列。Sharpe分母为策略原始收益波动率，按题目脚注。
3. RF字面Sharpe=0；不将其作为有经济意义的权益风险调整排名。
4. 1E主窗口含当月，属同期分析；滞后补充用截至前月的信息，两个模型均332个月。
5. MSCI方法按题目链接December 2013版说明，并不认定其覆盖整个样本历史。
6. 未对Part 1进行winsorize：题目的截尾要求属于Part 2，不能移用到因子收益。
7. 本报告未套用FF3个股回归或原30股组合，未执行任何交易或提交。
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
print(json.dumps({'1A':a.to_dict('records'),'1C':c.reset_index().to_dict('records'),'1D':corr.to_dict(),'1E':er.to_dict('records'),'checks':checks},ensure_ascii=False,indent=2))
