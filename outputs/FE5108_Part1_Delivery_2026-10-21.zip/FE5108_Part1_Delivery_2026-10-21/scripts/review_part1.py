"""Independent read-only recomputation from Excel using Python statistics.
Does not import build_part1 or consume its intermediate calculation files.
Only writes review_results.json. Run after build_part1.py.
"""
from pathlib import Path
import statistics as st
import math, json, datetime, hashlib
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
W=openpyxl.load_workbook(ROOT/'inputs/classroom_part1.xlsx',read_only=True,data_only=True)
T=ROOT/'tables'
import csv
def csvrows(name):
    with (T/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
results=[]
def check(label,actual,expected,tol=1e-10):
    error=abs(float(actual)-float(expected))
    results.append(dict(check=label,pass_check=bool(error<=tol),absolute_error=error,tolerance=tol))
    assert error<=tol,(label,actual,expected)

def block(sheet,kind):
    rows=list(W[sheet].values)
    if kind=='ff': start=next(i+1 for i,r in enumerate(rows) if len(r)>2 and r[1]=='Mkt-RF')
    else:
        marker=next(i for i,r in enumerate(rows) if isinstance(r[0],str) and 'Value Weighted' in r[0] and 'Monthly' in r[0])
        start=marker+2
    out={}
    for row in rows[start:]:
        v=row[0]
        if not isinstance(v,(int,float)) or v<190001:break
        v=int(v); key=f'{v//100:04d}-{v%100:02d}'
        assert key not in out
        out[key]=[float(x)/100 for x in row[1:]]
    return out
ff=block('FF - 3 factor returns','ff')
momlegs=block('FF - portfolios sorted on pmom','sorted')
betalegs=block('FF - portfolios sorted on beta','sorted')
mom={k:v[-1]-v[0] for k,v in momlegs.items()}
rows=list(W['FF - portfolios sorted on beta'].values)
header=next(r for r in rows if 'Lo 10' in r and 'Hi 10' in r)
ilo=header.index('Lo 10')-1; ihi=header.index('Hi 10')-1
beta={k:v[ilo]-v[ihi] for k,v in betalegs.items()}

for r in csvrows('1A_factor_mean_tests.csv'):
    lo,hi=('1927-01','1992-12') if r['period']=='1927-1992' else ('1993-01','2023-07')
    j={'Mkt-RF':0,'SMB':1,'HML':2}[r['factor']]
    v=[x[j] for k,x in ff.items() if lo<=k<=hi]
    tag=f'1A {r["period"]} {r["factor"]}'
    check(tag+' count',r['n'],len(v),0)
    check(tag+' mean',r['mean_monthly'],st.mean(v))
    check(tag+' t',r['t_mean'],st.mean(v)/(st.stdev(v)/math.sqrt(len(v))))

for r in csvrows('1A_mean_difference_supplement.csv'):
    j={'Mkt-RF':0,'SMB':1,'HML':2}[r['factor']]
    pre=[v[j] for k,v in ff.items() if '1927-01'<=k<='1992-12']
    post=[v[j] for k,v in ff.items() if '1993-01'<=k<='2023-07']
    delta=st.mean(post)-st.mean(pre)
    se=math.sqrt(st.variance(pre)/len(pre)+st.variance(post)/len(post))
    check('1A difference '+r['factor'],r['post_minus_pre_mean_monthly'],delta)
    check('1A difference SE '+r['factor'],r['se_monthly'],se)
    check('1A difference p '+r['factor'],r['p_two_sided_normal'],math.erfc(abs(delta/se)/math.sqrt(2)))

levels={}
for r in W['MSCI - factor totret index'].values:
    try:d=datetime.datetime.strptime(str(r[0]),'%b %d, %Y')
    except ValueError:continue
    levels[d.strftime('%Y-%m')]=[float(str(x).replace(',','')) for x in r[1:6]]
months=sorted(levels); returns={}
for prev,cur in zip(months,months[1:]):returns[cur]=[y/x-1 for x,y in zip(levels[prev],levels[cur])]
check('MSCI return months',len(returns),343,0)
data={k:[*v,st.mean(v[1:]),ff[k][3]] for k,v in returns.items()}
for i,r in enumerate(csvrows('1C_performance.csv')):
    v=[x[i] for x in data.values()]; rf=[x[-1] for x in data.values()]
    tag='1C '+r['strategy']; mean=12*st.mean(v);vol=math.sqrt(12)*st.stdev(v)
    check(tag+' mean',r['mean_annual_arithmetic'],mean)
    check(tag+' vol',r['vol_annual'],vol)
    check(tag+' sharpe',r['sharpe_assignment'],(mean-12*st.mean(rf))/vol)
    check(tag+' CAGR',r['cagr'],math.exp(st.mean([math.log1p(x) for x in v])*12)-1)

style_names=['Value','MinVol','EqualWeight','Momentum']
style_series=[[v[j] for v in returns.values()] for j in [1,2,3,4]]
cv=[[12*st.covariance(x,y) for y in style_series] for x in style_series]
cr=[[st.correlation(x,y) for y in style_series] for x in style_series]
for name,matrix in [('1C_factor_index_return_correlations.csv',cr),('1C_factor_index_covariance_annual.csv',cv)]:
    for i,r in enumerate(csvrows(name)):
        for j,col in enumerate(style_names):check('1C matrix '+name+' '+style_names[i]+'/'+col,r[col],matrix[i][j])
var_actual=sum(sum(row) for row in cv)/16
diag=sum(cv[i][i] for i in range(4))/16
perfect=st.mean(math.sqrt(cv[i][i]) for i in range(4))
actual=math.sqrt(var_actual)
dm={r['metric']:float(r['value']) for r in csvrows('1C_diversification_evidence.csv')}
expected={
 'mean_constituent_vol_and_perfect_positive_correlation_reference':perfect,
 'multifactor_vol_annual':actual,
 'vol_reduction_absolute':perfect-actual,
 'vol_reduction_relative':1-actual/perfect,
 'portfolio_variance_annual':var_actual,
 'diagonal_variance_component':diag,
 'off_diagonal_covariance_component':var_actual-diag,
 'perfect_positive_correlation_variance_reference':perfect**2,
 'variance_reduction_relative':1-var_actual/perfect**2,
 'minimum_pairwise_total_return_correlation':min(cr[i][j] for i in range(4) for j in range(i+1,4)),
 'maximum_pairwise_total_return_correlation':max(cr[i][j] for i in range(4) for j in range(i+1,4)),
}
for key,v in expected.items():check('1C diversification '+key,dm[key],v)
for i,r in enumerate(csvrows('1C_risk_contributions.csv')):
    contribution=sum(cv[i])/16
    check('1C risk contribution '+style_names[i],r['annual_variance_contribution'],contribution)
    check('1C risk fraction '+style_names[i],r['variance_contribution_fraction'],contribution/var_actual)

for i,r in enumerate(csvrows('1D_correlations_4x4.csv')):
    j={'Value':1,'MinVol':2,'EqualWeight':3,'Momentum':4}[r['']]
    active=[v[j]-v[0] for v in returns.values()]
    for name,series in [('HML',{k:v[2] for k,v in ff.items()}),('SMB',{k:v[1] for k,v in ff.items()}),('MOM_decile',mom),('LOWBETA_decile',beta)]:
        check('1D '+r['']+'/'+name,r[name],st.correlation(active,[series[k] for k in returns]))

def month_shift(k,n):
    y,m=map(int,k.split('-')); q=y*12+m-1+n
    return f'{q//12:04d}-{q%12+1:02d}'
analysis_months=[k for k in returns if k>='1995-12']
check('1E sample size',len(analysis_months),332,0)
y=[mom[k] for k in analysis_months]
voldict={}
for lag,name in [(0,'vol_t'),(1,'vol_t_minus_1')]:
    x=[math.sqrt(12)*st.stdev([ff[month_shift(k,-lag-j)][0] for j in range(12)]) for k in analysis_months]
    voldict[name]=x
    for r in csvrows('1E_monthly_analysis.csv'):
        i=analysis_months.index(r['month']);check('1E '+name+' window '+r['month'],r[name],x[i])
    lr=st.linear_regression(x,y); n=len(y); xbar=st.mean(x)
    residual=[yi-lr.intercept-lr.slope*xi for xi,yi in zip(x,y)]
    weights=[(xi-xbar)/sum((xi-xbar)**2 for xi in x) for xi in x]
    scores=[a*b for a,b in zip(weights,residual)]
    for lag_hac in [3,12]:
        variance=sum(z*z for z in scores)
        for h in range(1,lag_hac+1):
            variance+=2*(1-h/(lag_hac+1))*sum(scores[t]*scores[t-h] for t in range(h,n))
        se=math.sqrt(variance*n/(n-2))
        r=next(r for r in csvrows('1E_regressions_HAC.csv') if r['specification']==name and int(r['lags'])==lag_hac)
        tag=f'1E {name} HAC({lag_hac})'
        for field,expected in [('intercept',lr.intercept),('slope',lr.slope),('slope_se_hac',se),('slope_z_hac',lr.slope/se),('slope_p_hac_normal',math.erfc(abs(lr.slope/se)/math.sqrt(2))),('r_squared',st.correlation(x,y)**2)]:
            check(tag+' '+field,r[field],expected)
    # Independently reconstruct terciles by order statistics (111 / 110 / 111).
    order=sorted(range(n),key=lambda i:x[i]);groups=[order[:111],order[111:221],order[221:]]
    for label,g in zip(['Low','Middle','High'],groups):
        r=next(r for r in csvrows('1E_volatility_terciles.csv') if r['specification']==name and r['regime']==label)
        check(f'1E {name} {label} count',r['n'],len(g),0)
        check(f'1E {name} {label} mean',r['momentum_mean_monthly'],st.mean(y[i] for i in g))

# Verify influence diagnostic independently, retaining actual calendar gaps in HAC.
drop=sorted(range(len(y)),key=lambda i:y[i])[:2]
keep=[i for i in range(len(y)) if i not in drop]
for name,x in voldict.items():
    xx=[x[i] for i in keep]; yy=[y[i] for i in keep]
    lr=st.linear_regression(xx,yy); xbar=st.mean(xx);sxx=sum((xi-xbar)**2 for xi in xx)
    scores=[0.0]*len(y)
    for i in keep:scores[i]=(x[i]-xbar)/sxx*(y[i]-lr.intercept-lr.slope*x[i])
    var=sum(z*z for z in scores)
    for h in range(1,13):var+=2*(1-h/13)*sum(scores[i]*scores[i-h] for i in range(h,len(y)))
    se=math.sqrt(var*len(keep)/(len(keep)-2))
    r=next(r for r in csvrows('1E_extreme_month_sensitivity.csv') if r['specification']==name)
    check('1E sensitivity slope '+name,r['slope'],lr.slope)
    check('1E sensitivity HAC SE '+name,r['slope_se_hac'],se)
    check('1E sensitivity p '+name,r['slope_p_hac_normal'],math.erfc(abs(lr.slope/se)/math.sqrt(2)))

payload={'audit_date':datetime.date.today().isoformat(),'source_sha256':hashlib.sha256((ROOT/'inputs/classroom_part1.xlsx').read_bytes()).hexdigest(),'builder_sha256':hashlib.sha256((ROOT/'scripts/build_part1.py').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((ROOT/'Part1_report.html').read_bytes()).hexdigest(),'approach':'Independent raw Excel read; Python statistics means/stdev/correlation/linear_regression; scalar HAC projection with calendar order. Does not import production builder.','checks_count':len(results),'all_passed':all(r['pass_check'] for r in results),'max_absolute_error':max(r['absolute_error'] for r in results),'checks':results}
(ROOT/'review_results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in payload.items() if k!='checks'},ensure_ascii=False,indent=2))
